import view.ConsoleGetCommand;
public class Main {
    public static void main(String[] args) {
        ConsoleGetCommand.start();
    }
}